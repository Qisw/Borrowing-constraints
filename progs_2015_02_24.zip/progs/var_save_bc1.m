function var_save_bc1(saveS, varNo, cS, setNo, expNo)
% Save a variable file
% ------------------------------------------

if isempty(cS)
   cS = const_bc1(setNo, expNo);
end
% if nargin == 3
%    setNo = cS.setNo;
%    expNo = cS.expNo;
% end

[fn, fDir] = var_fn_bc1(varNo, cS);

if ~exist(fDir, 'dir')
   files_lh.mkdir_lh(fDir, cS.dbg);
end

save(fn, 'saveS');

fprintf('Saved variable %i  / set %i exp %i \n',  varNo, cS.setNo, cS.expNo);

end