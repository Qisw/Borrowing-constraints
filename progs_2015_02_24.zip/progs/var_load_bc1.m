function [loadS, success] = var_load_bc1(varNo, cS, setNo, expNo)
% Load a variable file
% ------------------------------------------

if isempty(cS)
   cS = const_bc1(setNo, expNo);
end
% if nargin == 2
%    setNo = cS.setNo;
%    expNo = cS.expNo;
% end

fn = var_fn_bc1(varNo, cS);

if exist(fn, 'file')
   loadS = load(fn);
   loadS = loadS.saveS;
   success = 1;
else
   loadS = [];
   success = 0;
end

end