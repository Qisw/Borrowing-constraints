function copy_shared_bc1(dirV, nameV, overWrite)
% Copy shared programs
%{
IN
   dirV
      list of dirs to be copied entirely
      or: empty (skip copying dirs)
      or: 'all' (copy all dirs)
   nameV
      list of files to be copied
      or: empty
      or: 'all'

%}
% -----------------------------------------

if nargin ~= 3
   error('Invalid nargin');
end

global lhS;
sourceBaseDir = lhS.sharedDir;
cS = const_bc1([]);
tgBaseDir = cS.sharedDir;



%% Copy entire directories
if ~isempty(dirV)
   if ischar(dirV)
      if strcmpi(dirV, 'all')
         % Copy all
         dirV = {'export_fig', '+preamble_lh'};
      else
         error('Invalid dirV');
      end
   end      
end



%% Copy individual files
if ~isempty(nameV)
   if ischar(nameV)
      if strcmpi(nameV, 'all')
         nameV = {'+figures_lh/const', '+figures_lh/new', '+figures_lh/format', '+figures_lh/fig_save_lh', ...
            '+files_lh/mkdir_lh', ...
            '+struct_lh/merge'};
      else
         error('Invalid nameV');
      end
   end
end

copy_shared_lh(dirV, nameV, overWrite, sourceBaseDir, tgBaseDir);

end