function fig_save(figFn, saveFigures, cS)

figS = const_fig_bc1;
figures_lh.fig_save_lh(figFn, saveFigures, figS.slideOutput, figS);

end