function run_all_bc1(setNo)
% Run everything in sequence



%% Test routines
if 0
   test_bc1.work(setNo);
   test_bc1.college(setNo);
end

end