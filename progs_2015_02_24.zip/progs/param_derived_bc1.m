function paramS = param_derived_bc1(paramS, cS)
% Derived parameters
%{
%}



%% Preferences

% Discount factor
paramS.prefBeta = cS.prefBetaDefault;

% Weight on leisure
paramS.prefPhi = cS.prefPhiDefault;


%% Preferences: Derived

% Consumption growth rate during work phase
paramS.gC = (paramS.prefBeta * cS.R) .^ (1 / cS.prefSigma);

% Present value factor
%  Present value of consumption = c at work start * pvFactor
%  Tested in value work
paramS.cPvFactor_sV = nan([cS.nSchool, 1]);
for iSchool = 1 : cS.nSchool
   paramS.cPvFactor_sV(iSchool) = sum((paramS.gC ./ cS.R) .^ (0 : (cS.workYears_sV(iSchool)-1)));
end


%% Endowments

paramS.mGridV = linspace(0, 1, cS.nTypes)';

paramS.prob_jV = ones([cS.nTypes, 1]) ./ cS.nTypes;
paramS.pColl_jV = linspace(1e3, 5e3, cS.nTypes)' ./ cS.unitAcct;
paramS.wColl_jV = linspace(2e3, 1e4, cS.nTypes)' ./ cS.unitAcct;
% Assets
paramS.k1_jV = linspace(0, 5e4, cS.nTypes)' ./ cS.unitAcct;

% Range of permitted assets (used for approximating value functions)
paramS.kMax = 2e5 ./ cS.unitAcct;


%% Ability grid

paramS.abilGridV = linspace(0, 1, cS.nTypes)';

paramS.prob_a_jM = linspace(1, 2, cS.nAbil)' * linspace(1, 2, cS.nTypes);
for j = 1 : cS.nTypes
   paramS.prob_a_jM(:,j) = paramS.prob_a_jM(:,j) ./ sum(paramS.prob_a_jM(:,j));
end


% ******  Derived

% Pr(a) = sum over j (pr(j) * pr(a|j))
paramS.prob_aV = nan([cS.nAbil, 1]);
for iAbil = 1 : cS.nAbil
   paramS.prob_aV(iAbil) = sum(paramS.prob_jV(:) .* paramS.prob_a_jM(iAbil,:)');
end



%% Graduation probs

paramS.prGradMin = 0.1;
paramS.prGradMax = 0.8;
paramS.prGradMult = 0.7;
paramS.prGradExp = 0.3;
paramS.prGradA0 = 0;


% *****  Derived

paramS.prGrad_aV = pr_grad_a_bc1(1 : cS.nAbil, paramS, cS);
paramS.prGrad_aV = paramS.prGrad_aV(:);



%% Earnings by [age, school, cohort]
% Including skill price

paramS.earn_ascM = repmat(cS.missVal, [cS.ageMax, cS.nSchool, cS.nCohorts]);

% currently invented +++++
for iCohort = 1 : cS.nCohorts
   for iSchool = 1 : cS.nSchool
      age1 = cS.ageWorkStart_sV(iSchool);
      age2 = cS.ageMax;

      T = age2 - age1 + 1;
      ageX = round((age2-age1) / 2);
      paramS.earn_ascM(age1 : age2, iSchool, iCohort) = ...
         [linspace(1, 2, ageX), linspace(2, 0, T-ageX)] .* 2e4 ./ cS.unitAcct;
   end
end


%% Borrowing limits

% Min k at start of each period
paramS.kMin_acM = repmat(-1e4 ./ cS.unitAcct, [cS.ageWorkStart_sV(cS.iCG), cS.nCohorts]);

end