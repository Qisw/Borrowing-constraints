function paramS = t_param_derived_bc1(setNo)

cS = const_bc1(setNo);

paramS.setNo = setNo;
paramS = param_derived_bc1(paramS, cS);


end