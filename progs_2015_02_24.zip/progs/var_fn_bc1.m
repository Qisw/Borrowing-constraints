function [fn, fDir, fName] = var_fn_bc1(varNo, cS, setNo, expNo)
% Variable name
% ----------------------------------

if isempty(cS)
   cS = const_bc1(setNo, expNo);
% else
%    setNo = cS.setNo;
%    expNo = cS.expNo;
end

% % Check consistency
% if (varNo >= 100  &&  varNo <= 199  &&  expNo ~= cS.dataExpNo)
%    error_rs('Invalid expNo', cS);
% end
% 
% % Variables that exist only for base expNo
% if (varNo >= 300  &&  varNo <= 399)  &&  expNo ~= cS.expBase
%    c2S = const_bc1(setNo, cS.expBase);
%    fDir = c2S.matDir;
% else
   fDir = cS.matDir;
% end

fName = sprintf('v%03i.mat', varNo);
fn = fullfile(fDir, fName);


end