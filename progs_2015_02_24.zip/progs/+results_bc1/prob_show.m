function prob_show(saveFigures, setNo, expNo)

if nargin < 2
   expNo = [];
end

cS = const_bc1(setNo, expNo);
figS = const_fig_bc1;
paramS = var_load_bc1(cS.vParams, cS);



%% Prob grad | a
if 1
   fh = output_bc1.fig_new(saveFigures, []);
   plot(cumsum(paramS.prob_aV), paramS.prGrad_aV, figS.lineStyleV{1});
   xlabel('Ability percentile');
   ylabel('Graduation probability');
   output_bc1.fig_format(fh, 'line');
   figFn = fullfile(cS.outDir, 'prob_grad_a');
   output_bc1.fig_save(figFn, saveFigures, cS);
end



end