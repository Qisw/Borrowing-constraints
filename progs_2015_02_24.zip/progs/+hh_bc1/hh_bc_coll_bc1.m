function kPrimeV = hh_bc_coll_bc1(cV, hoursV, kV, wColl, pColl, cS)
% Budget constraint in college

kPrimeV = cS.R * kV + 2 * (wColl * hoursV - cV- pColl);

end