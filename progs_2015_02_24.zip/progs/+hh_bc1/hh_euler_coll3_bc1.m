function [eeDevV, kPrimeV, hoursV] = hh_euler_coll3_bc1(cV, k, wColl, pColl, kMin, iCohort, paramS, cS)
% Euler equation deviation in college; periods 3-4
%{
Assumes INTERIOR solution for k'

eeDev > 0  implies  u'(c) > V_k  =>  raise c
%}

% Get work hours from static condition
hoursV = hh_bc1.hh_static_bc1(cV, wColl, paramS, cS);

% Get k' from budget constraint
kPrimeV = hh_bc1.hh_bc_coll_bc1(cV, hoursV, k, wColl, pColl, cS);
% kPrimeV = cS.R .* k + 2 * (wColl * hoursV - pColl - cV);

% Check that interior
if any(kPrimeV < kMin - 1e-6)
   error('Must be interior');
end

kPrimeV = max(kMin, kPrimeV);


% ***  EE dev

% % Marginal value of capital, discounted to start of work
% muKV = nan(size(cV));
% for i1 = 1 : length(cV)
%    [~,~,~, muKV(i1)] = hh_work_bc1(kPrimeV(i1), cS.iCG, iCohort, paramS, cS);
% end
% 
% % % MU(c) implied by Euler
% % ucV = 2 .* (paramS.prefBeta .^ 2) ./ (1 + paramS.prefBeta) .* muK;
% % 
% % % c implied by u'(c)
% % cV = hh_uprimec_inv_bc1(ucV, cS);
% 
% % ucV = cV .^ (-cS.prefSigma);
% ucV = hh_util_coll_bc1(cV, 1 - hoursV, paramS, cS);
% 
% eeDevV = (1 + paramS.prefBeta) .* ucV / 2  -  (paramS.prefBeta .^ 2) .* muKV;

eeDevV = hh_bc1.hh_eedev_coll3_bc1(cV, hoursV, kPrimeV, iCohort, paramS, cS);

if cS.dbg > 10
   validateattributes(eeDevV, {'double'}, {'finite', 'nonnan', 'nonempty', 'real', ...
      'size', size(cV)})
end

end