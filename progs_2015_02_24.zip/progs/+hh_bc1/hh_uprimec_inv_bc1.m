function cV = hh_uprimec_inv_bc1(ucV, cS)
% Inverse of u'(c) in college

cV = ucV .^ (-1 ./ cS.prefSigma);


if cS.dbg > 10
   validateattributes(cV, {'double'}, {'finite', 'nonnan', 'nonempty', 'real', ...
      'size', size(ucV)})
end

end