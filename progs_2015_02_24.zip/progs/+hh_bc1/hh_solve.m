function saveS = hh_solve(iCohort, paramS, cS)
% Solve hh problem. 1 cohort
%{
Change
   how to set k grids +++
%}
% -----------------------------------------


% Value work: closed form (hh_work)


%% Value of periods 3-4 in college

age = cS.ageWorkStart_sV(cS.iCD);

nk = 50;
vColl3S.kGridV = linspace(paramS.kMin_acM(age,iCohort), paramS.kMax, nk)';

% Compute on a k grid. 
sizeV = [nk, cS.nTypes];
vColl3S.c_kjM = nan(sizeV);
vColl3S.hours_kjM = nan(sizeV);
vColl3S.kPrime_kjM = nan(sizeV);
vColl3S.value_kjM = nan(sizeV);
% Interpolated value function for given j
% vColl3S.vColl3_jV = cell([cS.nTypes, 1]);

for j = 1 : cS.nTypes
   for ik = 1 : nk
      [vColl3S.c_kjM(ik,j), vColl3S.hours_kjM(ik,j), vColl3S.kPrime_kjM(ik,j), vColl3S.value_kjM(ik,j)] = ...
         hh_bc1.coll_pd3(vColl3S.kGridV(ik), paramS.wColl_jV(j), paramS.pColl_jV(j), iCohort, paramS, cS);
   end
   
%    vColl3S.vColl3_jV{j} = griddedInterpolant(vColl3S.kGridV, vColl3S.value_kjM(:,j), 'linear');
end

saveS.vColl3S = vColl3S;

if cS.dbg > 10
   validateattributes(vColl3S.value_kjM, {'double'}, {'finite', 'nonnan', 'nonempty', 'real', ...
      'size', [nk, cS.nTypes]})
end


%% Value at end of period 2, before learning ability

vmS.kGridV = vColl3S.kGridV;
vmS.value_kjM = nan([nk, cS.nTypes]);

for ik = 1 : nk
   % Value of working as a dropout
   [~, vDrop] = hh_bc1.hh_work_bc1(vmS.kGridV(ik), cS.iCD, iCohort, paramS, cS);
   for j = 1 : cS.nTypes
      % Value of studying in period 3-4
      vStudy = vColl3S.value_kjM(ik, j);
      % Value = E_a of (prob grad * study + prob drop * work)
      vmS.value_kjM(ik, j) = ...
         sum(paramS.prob_a_jM(:,j) .* ((1 - paramS.prGrad_aV) .* vDrop + paramS.prGrad_aV .* vStudy));
   end
end

saveS.vmS = vmS;

if cS.dbg > 10
   validateattributes(vmS.value_kjM, {'double'}, {'finite', 'nonnan', 'nonempty', 'real', ...
      'size', [nk, cS.nTypes]})
end



%% Periods 1-2 in college

sizeV = [nk, cS.nTypes];
v1S.kGridV = vmS.kGridV;
v1S.value_kjM = nan(sizeV);
v1S.c_kjM = nan(sizeV);
v1S.hours_kjM = nan(sizeV);
v1S.kPrime_kjM = nan(sizeV);


for j = 1 : cS.nTypes
   % Continuous approx of V_m(k', j) (continuation value)
   vmFct = griddedInterpolant(vmS.kGridV, vmS.value_kjM(:,j), 'pchip', 'linear');
   for ik = 1 : nk
      [v1S.c_kjM(ik,j), v1S.hours_kjM(ik,j), v1S.kPrime_kjM(ik,j), v1S.value_kjM(ik,j)] = ...
         hh_bc1.coll_pd1(vmS.kGridV(ik), paramS.wColl_jV(j), paramS.pColl_jV(j), ...
         iCohort, vmFct, paramS, cS);
   end
end

saveS.v1S = v1S;



%% College entry decision


end