function cV = coll_bc(kPrimeV, hoursV, kV, wColl, pColl, cS)
% Budget constraint in college

cV = (cS.R * kV - kPrimeV) ./ 2 + (wColl * hoursV - pColl);

end