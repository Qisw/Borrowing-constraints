function [cV, util, pvEarn, muK] = hh_work_bc1(k, iSchool, iCohort, paramS, cS)
% Household: work phase
%{
IN
   k
      initial assets
OUT
   cV
      consumption by age (during work phase)
   util
      utility = present value of u(c)
   pvEarn
      present value of lifetime earnings

Checked: 2015-Feb-18
%}

%% Input check
if cS.dbg > 10
   validateattributes(k, {'double'}, {'finite', 'nonnan', 'nonempty', 'real', 'scalar'})
end


%% Main

% Discount factors
dFactorV = (1 ./ cS.R) .^ (0 : (cS.workYears_sV(iSchool) - 1));

% Present value of earnings
%  discounted to work start
pvEarn = dFactorV * paramS.earn_ascM(cS.ageWorkStart_sV(iSchool) : cS.ageMax, ...
   iSchool, iCohort);


% Consumption at work start = (pv income) / pvFactor
c1 = (cS.R * k  +  pvEarn) ./ paramS.cPvFactor_sV(iSchool);
cV = c1 .* (paramS.gC .^ (0 : (cS.workYears_sV(iSchool)-1)));

[~, muV, util] = hh_bc1.util_work_bc1(cV, paramS, cS);


%% Marginal value of k
% Can just assume that additional k is eaten at first date

muK = muV(1) .* cS.R;



%% Self test
if cS.dbg > 10
   pvC = dFactorV * cV(:);
   if abs(cS.R * k + pvEarn - pvC) > 1e-4
      error_bc1('Invalid budget constraint', cS);
   end
end


end