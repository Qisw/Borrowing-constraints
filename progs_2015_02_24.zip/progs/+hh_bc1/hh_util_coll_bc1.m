function [muCV, muLV, utilV] = hh_util_coll_bc1(cV, leisureV, paramS, cS)
% Utility in college

%% Input check
if cS.dbg > 10
   validateattributes(cV, {'double'}, {'finite', 'nonnan', 'nonempty', 'real', ...
      'positive'})
   validateattributes(leisureV, {'double'}, {'finite', 'nonnan', 'nonempty', 'real', ...
      'positive'})
end


%% Main

% Consumption part
if cS.prefSigma == 1
   % Log utility
   utilCV = log(cV);
   muCV = 1 ./ cV;
else
   sig1 = 1 - cS.prefSigma;
   utilCV = cV .^ sig1 ./ sig1 - 1;
   muCV = cV .^ (-cS.prefSigma);
end

% Leisure part
if cS.prefRho == 1
   utilLV = paramS.prefPhi .* log(leisureV);
   muLV = paramS.prefPhi ./ leisureV;
else
   sig2 = 1 - cS.prefRho;
   utilLV = paramS.prefPhi .* ((leisureV .^ sig2) ./ sig2 - 1);
   muLV = paramS.prefPhi .* leisureV .^ (-cS.prefRho);
end

utilV = utilCV + utilLV;

%% Self-test
if cS.dbg > 10
   sizeV = size(cV);
   validateattributes(muCV, {'double'}, {'finite', 'nonnan', 'nonempty', 'real', 'positive', ...
      'size', sizeV})
   validateattributes(muLV, {'double'}, {'finite', 'nonnan', 'nonempty', 'real', 'positive', ...
      'size', sizeV})
   validateattributes(utilV, {'double'}, {'finite', 'nonnan', 'nonempty', 'real', ...
      'size', sizeV})
end

end