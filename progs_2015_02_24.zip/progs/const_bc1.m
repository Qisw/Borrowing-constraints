function cS = const_bc1(setNo, expNo)
% Set constants
%{
Index order: age, school, cohort
%}
% -----------------------------

cS.setDefault = 1;
cS.expBase = 1;
if isempty(setNo)
   setNo = cS.setDefault;
end
if nargin < 2
   expNo = cS.expBase;
end
if isempty(expNo)
   expNo = cS.expBase;
end
cS.setNo = setNo;
cS.expNo = expNo;
cS.dbg = 111;
setStr = sprintf('set%03i', setNo);
cS.missVal = -9191;
cS.pauseOnError = 1;


%% Miscellaneous

% 1 = $unitAcct
cS.unitAcct = 1e3;


%% Default parameters: Demographics, Preferences

% Age at model age 1
cS.age1 = 18;
% Last physical age
cS.physAgeLast = 75;
% Retirement age
% cS.physAgeRetire = 65;

% Discount factor
cS.prefBetaDefault = 0.98;
% Curvature of u(c)
cS.prefSigma = 1;
% Curvature of u(leisure)
cS.prefRho = 1;
% Weight on leisure
cS.prefPhiDefault = 0.5;
% Consumption floor
cS.cFloor = 500 ./ cS.unitAcct;
cS.lFloor = 0.05;

% Cohorts modeled
cS.bYearV = [1961, 1979];



%% Default: endowments

% Size of ability grid
cS.nAbil = 5;

% Number of types
cS.nTypes = 5;


%% Default: schooling

cS.iHSG = 1;
cS.iCD = 2;
cS.iCG = 3;
cS.nSchool = cS.iCG;
cS.sLabelV = {'HSG', 'CD', 'CG'};
cS.ageWorkStart_sV = [1; 3; 5];


%% Default: other

% Gross interest rate
cS.R = 1.04;



%% Derived constants

cS.nCohorts = length(cS.bYearV);

cS.ageMax = cS.physAgeLast - cS.age1 + 1;
% cS.ageRetire = cS.physAgeRetire - cS.age1 + 1;

% Length of work phase by s
cS.workYears_sV = cS.ageMax - cS.ageWorkStart_sV + 1;



%% Directories

cS.baseDir = fullfile('~', 'dropbox', 'hc', 'borrow_constraints', 'model1');
cS.progDir = fullfile(cS.baseDir, 'progs');
cS.matDir  = fullfile(cS.baseDir, 'mat', setStr);
cS.outDir  = fullfile(cS.baseDir, 'out', setStr);
cS.sharedDir = fullfile(cS.baseDir, 'shared');


%%  Saved variables

% Calibrated parameters
cS.vParams = 1;

% Hh solution
cS.vHhSolution = 2;


end